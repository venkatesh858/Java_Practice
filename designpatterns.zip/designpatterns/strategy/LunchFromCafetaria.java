package com.designpatterns.strategy;

public class LunchFromCafetaria implements Strategy {
	public void lunchOrder(){
		System.out.println("Order Lunch from Cafetaria..");
	}
}
