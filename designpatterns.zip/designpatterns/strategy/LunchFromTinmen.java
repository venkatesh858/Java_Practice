package com.designpatterns.strategy;

public class LunchFromTinmen implements Strategy {
	public void lunchOrder() {
		System.out.println("Order Lunch from Tinmen..");
	}
}
