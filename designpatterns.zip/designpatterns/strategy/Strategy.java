package com.designpatterns.strategy;

public interface Strategy {
		public void lunchOrder();
}