package com.designpatterns.strategy;

public class Runner {
	public static void main(String[] args) {
		LunchFromCafetaria cafetaria = new LunchFromCafetaria();
		LunchFromTinmen tinmen = new LunchFromTinmen();
		LunchFromDietToGo diettogo = new LunchFromDietToGo();

		tinmen.lunchOrder();		
	}
}
