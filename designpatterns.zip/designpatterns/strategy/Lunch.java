package com.designpatterns.strategy;

public class Lunch {
	private Strategy strategy;
 
	public Lunch(Strategy strategy){
		this.strategy = strategy;
	}
 
	public void handleByPolice(int speed){
		this.strategy.lunchOrder();
	}
}

