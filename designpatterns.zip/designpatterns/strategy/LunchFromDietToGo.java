package com.designpatterns.strategy;

public class LunchFromDietToGo implements Strategy{
	public void lunchOrder() {
		System.out.println("Order Lunch from Diet To Go..");
	}
}
