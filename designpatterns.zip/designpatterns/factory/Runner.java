package com.designpatterns.factory;

public class Runner {
	public static void main(String[] args) {

		Currency usa;
		try {
			usa = CurrencyFactory.getCurrencyByCountry("USA");
			System.out.println("USA currency: " + usa.getCurrency());
			System.out.println("USA currency symbol: " + usa.getSymbol());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
