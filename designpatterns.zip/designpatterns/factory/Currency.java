package com.designpatterns.factory;

public interface Currency {

	public String getCurrency();
	public String getSymbol();

}