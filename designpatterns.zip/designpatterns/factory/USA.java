package com.designpatterns.factory;

public class USA implements Currency {

	public String getCurrency() {

		return "Dollar";
	}

	public String getSymbol() {

		return "$";
	}

	public static void main(String a[]) {

		USA in = new USA();
		System.out.println(in.getSymbol());
	}
}