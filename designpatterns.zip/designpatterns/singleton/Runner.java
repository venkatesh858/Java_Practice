package com.designpatterns.singleton;

public class Runner {
	public static void main(String[] args) {
		SingletonLazyInitialization instance1= SingletonLazyInitialization.getInstance();
		SingletonLazyInitialization instance2= SingletonLazyInitialization.getInstance();

		System.out.println(instance1);
		System.out.println(instance2);
		
        if(instance1 == instance2){
            System.out.println("Both instances are same...");
        }
	}
}
