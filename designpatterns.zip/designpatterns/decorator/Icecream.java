package com.designpatterns.decorator;

public interface Icecream {
  public String makeIcecream();
}