package com.designpatterns.builder;

public class Runner {

	public static void main(String[] args) {
		StringBuilder builder = new StringBuilder();

		builder.append(" Hello");
		builder.append(" Test ");
		builder.append(5);

		System.out.println(builder.toString());
	}
}