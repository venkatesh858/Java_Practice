/* 
 * Program to demonstrate usage of HashSet
 */

package com.cleancode.task9dot1;

import java.util.*;  
class HashSetExample{  
 public static void main(String[] args){  
    
  HashSet<String> set=new HashSet<>();  
  set.add("Ravi");  
  set.add("Vijay");  
  set.add("Ravi");  
  set.add("Ajay");  
  
  Iterator<String> itr=set.iterator();  
  while(itr.hasNext()){  
   itr.next(); 
   
  }  
 }  
}  