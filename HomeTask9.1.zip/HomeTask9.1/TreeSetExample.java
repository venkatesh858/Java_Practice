/* 
 * Program to demonstrate usage of TreeSet
 */

package com.cleancode.task9dot1;

import java.util.*;  

class TreeSetExample{  

	public static void main(String[] args){  
	    
	  TreeSet<String> al=new TreeSet<>();  
	  al.add("Ram");  
	  al.add("Rahim");  
	  al.add("Rajesh");  
	  al.add("Rahul");  
	    
	  Iterator<String> itr=al.iterator();  
	  while(itr.hasNext()){
		 itr.next();  
  }  
 }  
}  