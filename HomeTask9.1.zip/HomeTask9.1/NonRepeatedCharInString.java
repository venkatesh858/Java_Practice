

/*
 * Run Sonar rules for home task 6.1
 * Program to print first non repeated character in given string
 */

package com.cleancode.task9dot1;

import java.util.LinkedHashMap;
import java.util.Map;

public class NonRepeatedCharInString {
	public void nonRepChar(String s) {

		Map<Character, Integer> map = new LinkedHashMap<>();
		char[] c = s.toCharArray();

		for (char ch : c) {
			if (map.containsKey(ch)) {
				int count = map.get(ch);
				map.put(ch, count + 1);
			} else {
				map.put(ch, 1);
			}
		}
		for (char ch : c) {
			if (map.get(ch) == 1) {

				break;
			}
		}
	}

	public static void main(String[] args) {
		NonRepeatedCharInString nr = new NonRepeatedCharInString();
		nr.nonRepChar("hello world");
	}
}