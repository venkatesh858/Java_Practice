/* 
 * Program to demonstrate usage of HashMap
 */

package com.cleancode.task9dot1;

import java.util.HashMap;

public class HashMapExample {

	public static void main(String[] args) {
		HashMap<Integer,String> hm = new HashMap<>();
		
		hm.put(2, "Venkat");
		hm.put(4, "Ravi");
		hm.put(5, "Shiva");
		hm.put(7, "Kalyan");
		

		
	}

}