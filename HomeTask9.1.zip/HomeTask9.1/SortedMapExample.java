/* 
 * Program to demonstrate usage of HashMap, LinkedHashMap, TreeMap
 */

package com.cleancode.task9dot1;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class SortedMapExample {

	public static void getMap(Map<Integer, String> map) {
		map.put(8, "Tiger");
		map.put(3, "Lion");
		map.put(5, "Fox");
		map.put(1, "Bear");
		map.put(12, "Dog");
	}

	public static void main(String[] args) {

		HashMap<Integer, String> hm = new HashMap<>();
		LinkedHashMap<Integer, String> lhm = new LinkedHashMap<>();
		TreeMap<Integer, String> tm = new TreeMap<>();

		getMap(hm);
		getMap(lhm);
		getMap(tm);

	}

}