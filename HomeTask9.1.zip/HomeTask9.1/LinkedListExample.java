/*
 * Program to demonstrate usage of Linked List
 */

package com.cleancode.task9dot1;

import java.util.LinkedList;

public class LinkedListExample {
	public static void main(String[] args){
		LinkedList<String> l1 = new LinkedList<>();
		l1.add("Venkat");
		l1.add("Vijay");
		l1.add("Ravi");
		l1.add("Ajay");

}}
