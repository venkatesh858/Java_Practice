/*
 * Run sonar rules for home task 4
 * 
 */

package com.cleancode.task9dot1;

public class Utilities {
	public int calculateTicket(int speed, boolean isBirthday) {
		int result = 0;
		if (!isBirthday) {
			if (speed <= 60)
				result = 0;
			else if ((speed >= 61) && (speed <= 80))
				result = 1;
			else if (speed >= 81)
				result = 2;
		} else {
			if (speed <= 65)
				result = 0;
			else if ((speed >= 66) && (speed <= 85))
				result = 1;
			else if (speed >= 86)
				result = 2;
		}
		return result;
	}

	public boolean compare(int a, int b) {

		return ((a == 6) || (b == 6) || ((a + b) == 6) || ((a - b) == 6) || ((b - a) == 6));
	}

	public int teaParty(int tea, int candy) {
		int result = 0;

		if (tea < 5 || candy < 5) {
			result = 0;
		} else {
			if ((tea >= (2 * candy)) || (candy >= (2 * tea))) {
				result = 2;
			} else if (tea >= 5 && candy >= 5) {
				result = 1;
			}
		}
		return result;
	}

	public int blueTicket(int a, int b, int c) {
		int result = 0;
		if ((a + b) == 10 || (b + c) == 10 || (a + c) == 10) {
			result = 10;
		} else if ((a + b) == (b + c + 10) || (a + b) == (a + c + 10)) {
			result = 5;
		} else {
			result = 0;
		}
		return result;
	}

	public boolean inOrder(int a, int b, int c, boolean bOk) {
		boolean result = bOk;
		if (bOk) {
			if (c > b) {
				result = true;
			} else {
				result = false;
			}
		} else {
			if (b > a && c > b) {
				result = true;
			} else {
				result = false;
			}
		}
		return result;
	}

	public boolean shareDigit(int a, int b) {
		int ld1 = a / 10;
		int rd1 = a % 10;

		int ld2 = b / 10;
		int rd2 = b % 10;

		return (ld1 == ld2 || ld1 == rd2 || rd1 == ld2 || rd1 == rd2);
	}

	public int sumLimit(int a, int b) {
		int result = 0;
		int lengthofsum = String.valueOf(a + b).length();
		int lengthofa = String.valueOf(a).length();
		if (lengthofsum == lengthofa)
			result = a + b;
		else if (lengthofsum > lengthofa)
			result = a;
		return result;
	}

	public String withoutString(String base, String remove) {
		String removestring = "(?i)" + remove;
		base = base.replaceAll(removestring, "");

		return base;
	}

	public int maxBlock(String str) {
		if (str.length() == 0)
			return 0;

		int largest = 0;
		int current = 1;

		for (int i = 1; i < str.length(); i++) {
			if (str.charAt(i) != str.charAt(i - 1)) {
				if (current > largest)
					largest = current;
				current = 1;
			} else {
				current++;
			}
		}
		return Math.max(largest, current);
	}

	public int sumNumbers(String str) {
		int len = str.length();
		int sum = 0;

		StringBuilder bld = new StringBuilder();
		for (int i = 0; i < len; ++i) {
			bld.append(str.charAt(i));
		}
		return sum;
	}

}
