/* 
 * Program to demonstrate usage of ArrayList
 */

package com.cleancode.task9dot1;

import java.util.ArrayList;

public class ArryListExample {

	public static void main(String[] args) {
		ArrayList<Integer> numbers = new ArrayList<>();

		// Add items
		numbers.add(10);
		numbers.add(20);
		numbers.add(30);
		numbers.add(40);
		

		for (int i=0;i<numbers.size();i++){
			numbers.get(i);
		}
		
		// Remove first item
		numbers.remove(0);
		
		// Remove last item
		numbers.remove(numbers.size()-1);
	
	}
}