/* 
 * Program to demonstrate usage of LinkedHashSet
 */

package com.cleancode.task9dot1;
  
import java.util.*;  

class LinkedHasSetExample{  
	
	public static void main(String[] args){  
	  LinkedHashSet<String> al=new LinkedHashSet<>();  
	  al.add("Nag");  
	  al.add("Shankar");  
	  al.add("Rohit");  
	  al.add("Avi");  
	  Iterator<String> itr=al.iterator();  
	  while(itr.hasNext()){  
		 itr.next();  
	  }  
 }  
} 