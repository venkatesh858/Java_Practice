package com.oops.flowerbouquet;

public class Rose extends Flower {
	public Rose() {
		this.cost = 4;
	}
}
