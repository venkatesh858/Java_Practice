package com.oops.flowerbouquet;

public class Client {

	public static void main(String[] args) {
		Bouquet myBouquet = new Bouquet();
		myBouquet.add(new Rose());
		myBouquet.add(new Jasmine());
		myBouquet.add(new Lilly());
		myBouquet.add(10, new Rose());
		myBouquet.getCostofBouguet(new Rose());
	}
}
