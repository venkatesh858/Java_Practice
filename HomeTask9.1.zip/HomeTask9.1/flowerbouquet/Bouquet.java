package com.oops.flowerbouquet;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Bouquet {
	protected List<Flower> flowers = new ArrayList<>();

	public void add(Flower flower) {
		flowers.add(flower);
	}

	public void add(int n, Flower flower) {
		for (int i = 0; i < n; i++) {
			flowers.add(flower);
		}
	}

	Iterator<Flower> iterator = flowers.iterator();

	public void getCostofBouguet(Flower flower) {
		int cost = 0;
		while (iterator.hasNext()) {
			cost = cost + flower.getCost();
		}
	}
}
