package com.oops.flowerbouquet;

public class Lilly extends Flower {
	public Lilly() {
		this.cost = 23;
	}
}